1. Syntax: extractor.exe -s -i infile -o outfile
	-s: turn on the slient mode

e.g. extractor.exe -s -i bus_cif.264 -o out.feat

2. Note that the "infile" must be a raw H.264 bitstream.